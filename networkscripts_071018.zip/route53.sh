#!/bin/bash +x
SEL=0
X=0
#ZID=""
usage="Usage:\n\t$(basename $0) Zone_Account_Alias Peer_Account_Alias [ZoneId]\n\n\t\tZone_Account_Alias:\n\t\t\tThe account where the Route53 hosted zone was provisioned.\n\n\t\tPeer_Account_Alias:\n\t\t\tThe account that requires resolution for the hosted zone.\n\n\t\tZoneId:\n\t\t\tThe Route53 ZoneId of the Hosted zone (Z..........).\n\n\nIf no arguments are given, an interactive dialog will allow you to choose based on preconfigured lists.\n"
#ACCT=`/usr/bin/aws iam list-account-aliases | grep 04 | tr -d '" '`
read -p "Enter Username: "  UN
echo ""
read -p "Enter Password":  -s PW
clear
#Management
DESCR[1]="management-prd"
ECIDR[1]="10.200.0.0/17"
WCIDR[1]="10.192.0.0/17"
TACCT[1]="kgc04183"
DESCR[2]="management-pse"
ECIDR[2]="10.200.128.0/17"
WCIDR[2]="10.192.128.0/17"
TACCT[2]="rsk0419b"
DESCR[3]="management-qa"
ECIDR[3]="10.201.0.0/17"
WCIDR[3]="10.193.0.0/17"
TACCT[3]="rsk0419c"
DESCR[4]="management-dev"
ECIDR[4]="10.201.128.0/17"
WCIDR[4]="10.193.128.0/17"
TACCT[4]="rsk0418m"

#Corporate
DESCR[5]="corporate-prd"
ECIDR[5]="10.202.0.0/17"
WCIDR[5]="10.194.0.0/17"
TACCT[5]="rsk0418b"
DESCR[6]="corporate-pse"
ECIDR[6]="10.202.128.0/17"
WCIDR[6]="10.194.128.0/17"
TACCT[6]="rsk0418l"
DESCR[7]="corporate-qa"
ECIDR[7]="10.203.0.0/17"
WCIDR[7]="10.195.0.0/17"
TACCT[7]="rsk0418k"
DESCR[8]="corporate-dev"
ECIDR[8]="10.203.128.0/17"
WCIDR[8]="10.195.128.0/17"
TACCT[8]="rsk0418j"

#Solutions
DESCR[9]="solutions-prd"
ECIDR[9]="10.204.0.0/17"
WCIDR[9]="10.196.0.0/17"
TACCT[9]="rsk04180"
DESCR[10]="solutions-pse"
ECIDR[10]="10.204.128.0/17"
WCIDR[10]="10.196.128.0/17"
TACCT[10]="rsk0418v"
DESCR[11]="solutions-qa"
ECIDR[11]="10.205.0.0/17"
WCIDR[11]="10.197.0.0/17"
TACCT[11]="rsk04182"
DESCR[12]="solutions-dev"
ECIDR[12]="10.205.128.0/17"
WCIDR[12]="10.197.128.0/17"
TACCT[12]="rsk04183"

#SIFMU/Core
DESCR[13]="sifmu-prd"
ECIDR[13]="10.206.0.0/17"
WCIDR[13]="10.198.0.0/17"
TACCT[13]="rsk0418n"
DESCR[14]="sifmu-pse"
ECIDR[14]="10.206.128.0/17"
WCIDR[14]="10.198.128.0/17"
TACCT[14]="rsk0418o"
DESCR[15]="sifmu-qa"
ECIDR[15]="10.207.0.0/17"
WCIDR[15]="10.199.0.0/17"
TACCT[15]="rsk0418p"
DESCR[16]="sifmu-dev"
ECIDR[16]="10.207.128.0/17"
WCIDR[16]="10.199.128.0/17"
TACCT[16]="rsk0418q"

if [[ $# -eq 3 || $# -eq 2 ]]; then
	for c in ${!TACCT[*]}; do
		if [ ${TACCT[${c}]} == $1 ]; then SEL=${c}; fi
		if [ ${TACCT[${c}]} == $2 ]; then X=${c}; fi
	done
	if [[ $SEL -eq 0 ]]; then echo -e "ERROR: Invalid Argument: $1"; fi
	if [[ $X -eq 0 ]]; then echo -e "ERROR: Invalid Argument: $2"; fi
	if [[ $SEL -eq 0 || $X -eq 0 ]]; then echo -e $usage; exit; fi
elif [ $# -gt 0 ]; then
	echo -e "ERROR: Invalid number of arguments\n$usage"
#	exit
else 
	echo "no"; #exit;
fi

for i in ${!DESCR[*]}; do 
	echo -e "  ${i}.\t${DESCR[${i}]}"
done
until [ ${SEL} -ne 0 ]; do
	read -p "Please choose the account where the hosted zone was created: " SEL;
	echo ""
	case ${SEL} in
		[1-9]|[1[0-6]*)
			echo "${SEL}) ${DESCR[${SEL}]}: ${TACCT[${SEL}]},${ECIDR[${SEL}]},${WCIDR[${SEL}]}"
			;;
		q)
			echo "Exiting..."
			exit;
			;;
		*)
			echo  "Invalid Entry: \"${SEL}\""
			SEL=0
			;;
	esac
done;
clear

echo "Logging into account ${TACCT[${SEL}]} to construct list of zones"
export `/opt/cloud/bin/awsauthz $UN $PW AP_AWS_SAML_${TACCT[${SEL}]}_role-admin-Network`

i=1
for a in $(aws route53 list-hosted-zones | grep "\"Name\"\|/hostedzone/" | grep -o "Z[A-Z0-9]\{11,15\}\|\"[a-zA-Z0-9.-]*\.\""); do 
	if [[ $a == Z* ]]; then
		ZONES[${i}]=${a};
	else
		DOMNS[${i}]=$(echo ${a} | tr -d '"');
		((i++))
	fi
done;
for i in ${!ZONES[*]}; do 
	echo -e "  ${i}.\t${ZONES[${i}]} - ${DOMNS[${i}]}"
	if [ -n "$3" ]; then
		if [ ${ZONES[${i}]} == $3 ]; then ZID=${i}; break; fi
	fi
done
if [[ -n "$3" && -z "$ZID" ]]; then echo "Invalid Argument: $3"; fi
while [ -z "$ZID" ]; do 
	read -p "Select number of domain from above or enter hosted zone ID: " ZID
	if [[ $ZID =~ ^[0-9]+$ ]]; then
		if [ $ZID -le ${#ZONES[@]} ]; then
			echo "Zone Selected: ${ZONES[${ZID}]} - ${DOMNS[${ZID}]}"
		fi
	elif [[ $ZID =~ ^Z[A-Z0-9]{11,15}$ ]]; then
		echo -ne "Zone Entered: ${ZID}"
		for a in ${!ZONES[*]}; do
			if [ ${ZONES[${a}]} == ${ZID} ]; then
				ZID=${a}
				echo ${DOMNS[${a}]}
			fi
		done
		echo ""
	elif [[ $ZID == q* ]]; then
		echo "Exiting..."
		exit
	else 
		echo "Invalid entry"
		ZID=""
	fi
done;

clear

for i in ${!DESCR[*]}; do 
	echo -e "  ${i}.\t${DESCR[${i}]}"
done
until [ ${X} -ne 0 ]; do
	read -p "Please choose the account where the central DNS server resides: " X;
	echo ""
	case ${X} in
		[1-9]|[1[0-6]*)
			echo "${X}) ${DESCR[${X}]}: ${TACCT[${X}]},${ECIDR[${X}]},${WCIDR[${X}]}"
			;;
		q)
			echo "Exiting..."
			exit;
			;;
		*)
			echo  "Invalid Entry: \"${X}\""
			SEL=0
			;;
	esac
done;

clear
echo -e "Hosting Account :   \t${DESCR[${SEL}]} (${TACCT[${SEL}]}) "
echo -e "Route53 Zone    :   \t${DOMNS[${ZID}]} (${ZONES[${ZID}]})"
echo -e "Target  Account :   \t${DESCR[${X}]} (${TACCT[${X}]}) "
read -p "Is this correct? " ANS
case ${ANS} in 
	[Yy]|[Yy][Ee][Ss])
		echo "Applying"
		;;
	*)
		echo "XXX"$ANS"XXX"
		echo "Cancelling..."
		exit;
	;;
esac

clear
echo "Logging into target account ${TACCT[${X}]} to identify VpcIds"
export `/opt/cloud/bin/awsauthz $UN $PW AP_AWS_SAML_${TACCT[${X}]}_role-admin-Network`

EVPCI[${X}]=$(aws ec2 describe-vpcs --region us-east-1 --filters="Name=cidr,Values=${ECIDR[${X}]}" | grep "VpcId" | grep -o "vpc-[0-9a-h]*")
WVPCI[${X}]=$(aws ec2 describe-vpcs --region us-west-2 --filters="Name=cidr,Values=${WCIDR[${X}]}" | grep "VpcId" | grep -o "vpc-[0-9a-h]*")
echo ${EVPCI[${X}]}
echo ${WVPCI[${X}]}

echo "Logging into hosted account ${TACCT[${SEL}]} to create authorization"
export `/opt/cloud/bin/awsauthz $UN $PW AP_AWS_SAML_${TACCT[${SEL}]}_role-admin-Network`

/usr/bin/aws route53 create-vpc-association-authorization --hosted-zone-id /hostedzone/${ZONES[${ZID}]} --vpc VPCRegion=us-east-1,VPCId=${EVPCI[${X}]}

/usr/bin/aws route53 create-vpc-association-authorization --hosted-zone-id /hostedzone/${ZONES[${ZID}]} --vpc VPCRegion=us-west-2,VPCId=${WVPCI[${X}]}

echo "Logging into target account ${TACCT[${X}]} to accept authorization"
export `/opt/cloud/bin/awsauthz $UN $PW AP_AWS_SAML_${TACCT[${X}]}_role-admin-Network`

/usr/bin/aws route53 associate-vpc-with-hosted-zone --hosted-zone-id /hostedzone/${ZONES[${ZID}]}  --vpc VPCRegion=us-east-1,VPCId=${EVPCI[${X}]}

/usr/bin/aws route53 associate-vpc-with-hosted-zone --hosted-zone-id /hostedzone/${ZONES[${ZID}]}  --vpc VPCRegion=us-west-2,VPCId=${WVPCI[${X}]}

echo "Logging into hosted account ${TACCT[${SEL}]} to clean up"
export `/opt/cloud/bin/awsauthz $UN $PW AP_AWS_SAML_${TACCT[${SEL}]}_role-admin-Network`

/usr/bin/aws route53 delete-vpc-association-authorization --hosted-zone-id /hostedzone/${ZONES[${ZID}]} --vpc VPCRegion=us-west-2,VPCId=${WVPCI[${X}]}

/usr/bin/aws route53 delete-vpc-association-authorization --hosted-zone-id /hostedzone/${ZONES[${ZID}]} --vpc VPCRegion=us-east-1,VPCId=${EVPCI[${X}]}

